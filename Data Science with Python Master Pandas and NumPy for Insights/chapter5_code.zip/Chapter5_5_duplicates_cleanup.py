import pandas as pd

# Finding Duplicates
duplicates = df.duplicated()
print(df[duplicates])

# Removing Duplicates
df_no_dupes = df.drop_duplicates()

# Keep the Most Recent Entry per person
df_sorted = df.sort_values('Date')
df_unique = df_sorted.drop_duplicates(subset='Name', keep='last')

# Hands-On: Duplicate Cleanup
df = pd.DataFrame({
    'Product': ['Milk', 'Bread', 'Milk'],
    'Price': [2.5, 1.8, 2.5],
    'Quantity': [30, 20, 30]
})

print(df.duplicated())
df = df.drop_duplicates()
print(df)