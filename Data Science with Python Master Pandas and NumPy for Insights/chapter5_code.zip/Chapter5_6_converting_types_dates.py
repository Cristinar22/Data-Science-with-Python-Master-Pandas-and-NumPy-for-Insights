import pandas as pd

# Check data types
print(df.dtypes)

# Convert to numeric
df['Score'] = pd.to_numeric(df['Score'], errors='coerce')

# Convert to datetime
df['Visit Date'] = pd.to_datetime(df['Visit Date'], errors='coerce')

# Hands-On: Parsing Dates
data = {
    'Name': ['Aisha', 'Tom', 'Ngozi'],
    'Visit Date': ['2023-05-01', '01/06/2023', '2023.07.15']
}
df_dates = pd.DataFrame(data)
df_dates['Visit Date'] = pd.to_datetime(df_dates['Visit Date'], errors='coerce')
print(df_dates['Visit Date'])