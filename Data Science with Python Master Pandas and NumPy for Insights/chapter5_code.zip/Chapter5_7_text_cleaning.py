import pandas as pd
import numpy as np

# Lowercase everything
df['City'] = df['City'].str.lower()

# Remove spaces
df['City'] = df['City'].str.strip()

# Replace or Remove Text
df['City'] = df['City'].str.replace('lagos ', 'lagos')
df['Score'] = df['Score'].replace(['n/a', ' '], np.nan)

# Split and Extract Parts
df['First Name'] = df['Full Name'].str.split().str[0]

# Hands-On: Clean Up City Names
df = pd.DataFrame({'City': ['lagos', 'Abuja', 'lagos', 'LAGOS']})
df['City'] = df['City'].str.lower().str.strip()
df['City'] = df['City'].replace({'lagos': 'Lagos', 'abuja': 'Abuja'})
print(df)