import pandas as pd

# Identifying Missing Data
print(df.isnull().sum())

# Dropping Missing Data
df_clean = df.dropna()
print(df_clean.shape)

df_clean = df.dropna(subset=['Age'])

# Filling Missing Data
df_filled = df.fillna(0)  # Replace all NaN with zero
mean_age = df['Age'].mean()
df['Age'] = df['Age'].fillna(mean_age)
df['Blood Pressure'] = df['Blood Pressure'].fillna(method='ffill')

# Interpolating Missing Data
df['Temperature'] = df['Temperature'].interpolate()

# Hands-On: Missing Data in Action
df = pd.DataFrame({
    'Name': ['Aisha', 'Tom', 'Ngozi'],
    'Age': [23, None, 21],
    'City': ['Lagos', 'Abuja', None],
    'Score': [89, 76, None]
})

print(df.isnull().sum())
df['Age'] = df['Age'].fillna(df['Age'].mean())
df = df.dropna(subset=['Score'])
print(df)