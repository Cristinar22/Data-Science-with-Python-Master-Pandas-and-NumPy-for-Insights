import pandas as pd

# Step 1: Load and Inspect
df = pd.read_csv('health_survey.csv')
print(df.head())
print(df.info())

# Step 2: Handle Missing Values
df['Age'] = df['Age'].fillna(df['Age'].median())
df = df.dropna(subset=['Score'])

# Step 3: Remove Duplicates
df = df.drop_duplicates(subset=['Name'])

# Step 4: Clean City Names
df['City'] = df['City'].str.lower().str.strip()
df['City'] = df['City'].replace({'lagos': 'Lagos', 'abuja': 'Abuja'})

# Step 5: Parse Dates
df['Visit Date'] = pd.to_datetime(df['Visit Date'], errors='coerce')

# Step 6: Check Everything
print(df.info())
print(df.head())