import pandas as pd

# Step 1: Load the Data
df = pd.read_csv('survey_data.csv')
print(df.head())
print(df.info())

# Step 2: Look for Issues
print("Duplicates count:", df.duplicated().sum())
print(df.describe(include='all'))