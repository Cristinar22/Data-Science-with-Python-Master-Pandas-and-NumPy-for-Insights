# Hands-On 1: Play with Variables
my_age = 24
friend_age = 27

average = (my_age + friend_age) / 2
print("Average age:", average)
