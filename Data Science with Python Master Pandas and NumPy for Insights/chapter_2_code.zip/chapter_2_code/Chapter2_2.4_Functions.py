# Functions: Building Your Own Tools
def greet(name):
    print("Hello,", name)

def add(a, b):
    return a + b

greet("Aisha")
greet("Tom")
total = add(4, 7)
print("Total:", total)
