# Dictionaries: Labelled Data
student = {
    "name": "Aisha",
    "age": 19,
    "score": 87
}
print(student["name"])   # "Aisha"
