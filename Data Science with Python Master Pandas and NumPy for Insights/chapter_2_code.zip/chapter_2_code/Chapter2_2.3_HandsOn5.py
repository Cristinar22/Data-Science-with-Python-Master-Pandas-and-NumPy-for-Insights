# Hands-On 5: If-Else and Loops
results = [72, 55, 80, 61, 90]
for result in results:
    if result >= 60:
        print("Pass:", result)
    else:
        print("Fail:", result)

passing = [r for r in results if r >= 60]
print("Passing scores:", passing)
