# Project 3: Unique Visitors Counter
visitors = ["alice", "bob", "alice", "jane", "bob", "dave"]
unique_visitors = set(visitors)
print("Unique visitors:", len(unique_visitors))
