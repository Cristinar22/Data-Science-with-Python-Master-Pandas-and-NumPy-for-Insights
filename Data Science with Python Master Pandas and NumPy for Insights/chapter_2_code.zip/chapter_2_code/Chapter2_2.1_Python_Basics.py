# Python Basics: Your Superpower for Data Science
# Variables
age = 30
name = "Femi"
price = 9.99

# Data Types
print(type(age))     # <class 'int'>
print(type(price))   # <class 'float'>
print(type(name))    # <class 'str'>

# Operators
total = 5 + 3      # 8
discounted = price * 0.8   # 7.992
greeting = "Hello, " + name   # "Hello, Femi"
