# Hands-On 6: Your First Function
def square(num):
    return num * num

print("4 squared is", square(4))
print("7 squared is", square(7))
