# If-Else Statements
temperature = 34

if temperature > 30:
    print("It's a hot day!")
else:
    print("Not too hot.")

# Loops
scores = [88, 92, 79, 93, 85]
for score in scores:
    print("Score:", score)

count = 0
while count < 3:
    print("Counting:", count)
    count += 1

# List Comprehension
bonus_scores = [score + 5 for score in scores]
print(bonus_scores)
