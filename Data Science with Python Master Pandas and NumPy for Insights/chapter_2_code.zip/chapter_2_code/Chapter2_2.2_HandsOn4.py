# Hands-On 4: Sets and Tuples
birthday = (12, "July", 1995)

my_numbers = [2, 3, 3, 5, 2, 8]
unique_numbers = set(my_numbers)
print(unique_numbers)
