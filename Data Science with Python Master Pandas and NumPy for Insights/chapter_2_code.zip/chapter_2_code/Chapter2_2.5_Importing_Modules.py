# Importing Modules: Expanding Your Toolbox
import math
print("Square root of 16 is", math.sqrt(16))
print("Pi is", math.pi)

from datetime import datetime
now = datetime.now()
print("Right now:", now)
