# Mini-Challenges for You to Try

# 1. Temperature Converter
def c_to_f(celsius):
    return (celsius * 9/5) + 32

print(c_to_f(0))    # 32.0
print(c_to_f(100))  # 212.0

# 2. Sum Only Even Numbers in a List
numbers = [3, 6, 8, 11, 14]
even_sum = sum([n for n in numbers if n % 2 == 0])
print("Sum of evens:", even_sum)

# 3. Check if a Word is a Palindrome
def is_palindrome(word):
    return word == word[::-1]

print(is_palindrome("level"))   # True
print(is_palindrome("hello"))   # False

# 4. Dictionary Look-Up
capitals = {"Nigeria": "Abuja", "Kenya": "Nairobi", "Egypt": "Cairo"}
country = "Nigeria"
print("Capital:", capitals.get(country, "Not found"))
