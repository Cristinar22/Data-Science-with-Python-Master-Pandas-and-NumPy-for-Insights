# Hands-On 3: Dictionary Time
product = {
    "id": 101,
    "name": "Laptop",
    "price": 350.50,
    "in_stock": True
}

print("Price:", product["price"])
