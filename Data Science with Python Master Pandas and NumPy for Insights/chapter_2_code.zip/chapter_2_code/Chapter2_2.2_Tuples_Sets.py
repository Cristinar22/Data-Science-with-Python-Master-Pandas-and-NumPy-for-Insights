# Tuples: Immutable Sequences
location = (6.5244, 3.3792)    # Latitude, Longitude

# Sets: Unique Items Only
unique_ids = {101, 102, 103, 101, 102}
print(unique_ids)   # {101, 102, 103}
