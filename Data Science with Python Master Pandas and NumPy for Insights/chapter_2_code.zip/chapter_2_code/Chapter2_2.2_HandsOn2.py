# Hands-On 2: List Practice
foods = ["Rice", "Beans", "Chicken"]

print("Second food:", foods[1])

foods.append("Yam")
print(foods)
