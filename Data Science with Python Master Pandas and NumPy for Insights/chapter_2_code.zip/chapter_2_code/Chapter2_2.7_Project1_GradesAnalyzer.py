# Project 1: Student Grades Analyzer
students = [
    {"name": "Aisha", "score": 88},
    {"name": "Ngozi", "score": 73},
    {"name": "Tom", "score": 65},
    {"name": "Bola", "score": 55},
    {"name": "Ife", "score": 91}
]

highest = max([student["score"] for student in students])
print("Highest score:", highest)

total = sum([student["score"] for student in students])
average = total / len(students)
print("Average score:", average)

for student in students:
    if student["score"] >= 60:
        print(student["name"], "passed.")
    else:
        print(student["name"], "failed.")
