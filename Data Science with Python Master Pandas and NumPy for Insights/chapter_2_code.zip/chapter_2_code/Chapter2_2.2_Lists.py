# Lists: Ordered Collections
scores = [88, 92, 79, 93, 85]
print(scores[0])      # 88 (the first item)
print(scores[-1])     # 85 (the last item)

names = ["Aisha", "Ngozi", "Tom"]
prices = [1.99, 2.49, 3.50]
mixed = ["Apple", 3, True]
