# Project 2: Inventory Value Calculator
products = [
    {"name": "Milk", "price": 2.5, "quantity": 30},
    {"name": "Bread", "price": 1.8, "quantity": 20},
    {"name": "Eggs", "price": 0.25, "quantity": 100}
]

total_value = sum([item["price"] * item["quantity"] for item in products])
print("Total inventory value is $", total_value)
