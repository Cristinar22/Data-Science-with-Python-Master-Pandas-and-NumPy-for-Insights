import pandas as pd

# Group by one column
sales = {
    'Region': ['Lagos', 'Abuja', 'Lagos', 'Kano', 'Abuja'],
    'Sales': [200, 150, 250, 100, 180]
}
df = pd.DataFrame(sales)
grouped_sum = df.groupby('Region')['Sales'].sum()
print(grouped_sum)

# Group by multiple columns
data = {
    'Region': ['Lagos', 'Lagos', 'Abuja', 'Abuja'],
    'Category': ['Dairy', 'Bakery', 'Dairy', 'Bakery'],
    'Sales': [200, 120, 150, 180]
}
df_multi = pd.DataFrame(data)
grouped_multi = df_multi.groupby(['Region', 'Category'])['Sales'].sum()
print(grouped_multi)

# Common aggregation functions
print(df_multi.groupby('Region')['Sales'].mean())
print(df_multi.groupby('Category')['Sales'].count())

# Custom aggregations
def range_func(x):
    return x.max() - x.min()

agg_results = df_multi.groupby('Region')['Sales'].agg(['sum', 'mean', 'max'])
print(agg_results)

custom_agg = df_multi.groupby('Region')['Sales'].agg(['mean', range_func])
print(custom_agg)
