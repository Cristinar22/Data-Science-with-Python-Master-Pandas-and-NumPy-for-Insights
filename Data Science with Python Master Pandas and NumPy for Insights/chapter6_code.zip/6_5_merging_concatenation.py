import pandas as pd

# Merging (SQL-style join)
products = pd.DataFrame({
    'Product': ['Milk', 'Bread', 'Eggs'],
    'Category': ['Dairy', 'Bakery', 'Poultry']
})
sales = pd.DataFrame({
    'Product': ['Milk', 'Bread', 'Eggs', 'Bread'],
    'Sales': [200, 180, 150, 175]
})
merged = pd.merge(sales, products, on='Product', how='left')
print(merged)

# Different types of joins
inner_join = pd.merge(sales, products, on='Product', how='inner')
left_join = pd.merge(sales, products, on='Product', how='left')
right_join = pd.merge(sales, products, on='Product', how='right')
outer_join = pd.merge(sales, products, on='Product', how='outer')
print(inner_join, left_join, right_join, outer_join, sep='\n\n')

# Concatenating DataFrames
df1 = pd.DataFrame({'A': [1, 2]})
df2 = pd.DataFrame({'A': [3, 4]})
concat_rows = pd.concat([df1, df2], ignore_index=True)
print(concat_rows)
concat_cols = pd.concat([df1, df2], axis=1)
print(concat_cols)
