import pandas as pd

# Step 1: Load the Data
sales = pd.DataFrame({
    'Date': ['2023-01-01', '2023-01-01'],
    'Region': ['Lagos', 'Abuja'],
    'Product': ['Milk', 'Bread'],
    'Sales': [250, 180]
})
products = pd.DataFrame({
    'Product': ['Milk', 'Bread', 'Eggs'],
    'Category': ['Dairy', 'Bakery', 'Poultry']
})

# Step 2: Merge Sales with Product Info
df = pd.merge(sales, products, on='Product', how='left')

# Step 3: Total Sales Per Region
region_sales = df.groupby('Region')['Sales'].sum()
print(region_sales)

# Step 4: Average Sales Per Category
category_avg = df.groupby('Category')['Sales'].mean()
print(category_avg)

# Step 5: Pivot Table—Sales by Region and Category
pivot = pd.pivot_table(df, values='Sales', index='Region', columns='Category', aggfunc='sum', fill_value=0)
print(pivot)

# Step 6: Find Top Category in Each Region
top_categories = pivot.idxmax(axis=1)
print(top_categories)

# Step 7: Save Results
pivot.to_csv("region_category_sales.csv")
print("Saved pivot table to region_category_sales.csv")
