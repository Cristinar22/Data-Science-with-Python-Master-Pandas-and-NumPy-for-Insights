import pandas as pd

# Sorting by one column
data = {
    'Product': ['Milk', 'Bread', 'Eggs', 'Yogurt'],
    'Price': [2.5, 1.8, 0.25, 3.0],
    'Quantity': [30, 20, 100, 15]
}
df = pd.DataFrame(data)
sorted_by_price = df.sort_values('Price')
print(sorted_by_price)

# Sorting by multiple columns
sorted_multi = df.sort_values(['Quantity', 'Price'], ascending=[False, True])
print(sorted_multi)

# Sort in place
df.sort_values('Price', inplace=True)

# Ranking
df['Price Rank'] = df['Price'].rank(ascending=False)
print(df)

# Hands-On: Ranking Practice
scores = {
    'Student': ['Aisha', 'Ngozi', 'Tom', 'Bola'],
    'Score': [88, 76, 92, 76]
}
df_scores = pd.DataFrame(scores)
df_scores['Rank'] = df_scores['Score'].rank(ascending=False, method='min')
print(df_scores.sort_values('Rank'))
