import pandas as pd

# Pivot Table
data = {
    'Region': ['Lagos', 'Abuja', 'Lagos', 'Abuja'],
    'Category': ['Poultry', 'Bakery', 'Dairy', 'Bakery'],
    'Sales': [150, 180, 250, 180]
}
df = pd.DataFrame(data)
pivot = pd.pivot_table(df, values='Sales', index='Region', columns='Category', aggfunc='sum', fill_value=0)
print(pivot)

# Cross-Tabulation
crosstab = pd.crosstab(df['Region'], df['Category'])
print(crosstab)
