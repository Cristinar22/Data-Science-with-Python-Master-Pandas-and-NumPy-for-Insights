# Mini-Challenges
# 1. Monthly Analysis:
#    - Group sales data by month and region.
#    - Find the region with highest sales each month.
#
# 2. Best Sellers:
#    - Group by product, sum sales, and find top 3 products.
#
# 3. Missing Products:
#    - After merging, find any sales without matching product info.
