import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression

# Load data and split as per 10.2
df = pd.read_csv('student_scores.csv')
features = ['Hours_Studied', 'Attendance', 'Previous_Score']
target = 'Final_Score'
X = df[features]
y = df[target]
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Step 1: Correlation Analysis
sns.pairplot(df)
plt.show()
print(df.corr())

# Step 2: Build and Train Linear Regression Model
model = LinearRegression()
model.fit(X_train, y_train)

# Step 3: Make Predictions
y_pred = model.predict(X_test)
print(y_pred)

# Step 4: Compare Predictions to Actual Values
results = pd.DataFrame({'Actual': y_test, 'Predicted': y_pred})
print(results.head())

# Step 5: Visualize Results
plt.scatter(y_test, y_pred)
plt.xlabel('Actual Scores')
plt.ylabel('Predicted Scores')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--')
plt.show()
