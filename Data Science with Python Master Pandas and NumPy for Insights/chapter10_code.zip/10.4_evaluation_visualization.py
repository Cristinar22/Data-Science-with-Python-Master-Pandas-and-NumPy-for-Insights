import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Assuming y_test and y_pred are loaded or computed
# Example: reload predictions from previous step
results = pd.read_csv('results.csv')  # containing 'Actual' and 'Predicted' columns
y_test = results['Actual']
y_pred = results['Predicted']

# Evaluation Metrics
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print('MAE:', mae)
print('MSE:', mse)
print('R2:', r2)

# Visualize Prediction Errors
errors = y_test - y_pred
plt.hist(errors, bins=10)
plt.title('Prediction Errors')
plt.xlabel('Error')
plt.ylabel('Count')
plt.show()
