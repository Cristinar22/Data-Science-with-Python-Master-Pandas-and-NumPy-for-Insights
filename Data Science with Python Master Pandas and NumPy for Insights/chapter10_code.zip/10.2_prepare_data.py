import pandas as pd
from sklearn.model_selection import train_test_split

# Step 1: Load Your Data
df = pd.read_csv('student_scores.csv')

# Step 2: Select Features and Target
features = ['Hours_Studied', 'Attendance', 'Previous_Score']
target = 'Final_Score'
X = df[features]
y = df[target]

# Step 3: Encoding Categorical Data (example: Gender, School)
if 'Gender' in df.columns:
    df['Gender'] = df['Gender'].map({'Male': 0, 'Female': 1})
if 'School' in df.columns:
    df = pd.get_dummies(df, columns=['School'], drop_first=True)

# Step 4: Check for Missing Values and Clean
print(df.isnull().sum())
df = df.dropna()

# Step 5: Split into Training and Test Data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
