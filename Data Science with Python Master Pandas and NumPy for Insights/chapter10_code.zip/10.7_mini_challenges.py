# Mini-Challenge 1: Predict Recovery Days
# Using patient data with features like age, initial severity, and treatment
# Steps: load data, preprocess, split, train a regression model, evaluate.

# Mini-Challenge 2: Forecast Deliveries
# Use logistics data to predict number of deliveries based on number of trucks and distance.
# Steps: similar pipeline as above.

# Mini-Challenge 3: Explore Nonlinear Model
from sklearn.tree import DecisionTreeRegressor
# After preparing X_train, y_train as above:
# model = DecisionTreeRegressor(random_state=42)
# model.fit(X_train, y_train)
# y_pred = model.predict(X_test)
# Evaluate with MAE, MSE, R2.
