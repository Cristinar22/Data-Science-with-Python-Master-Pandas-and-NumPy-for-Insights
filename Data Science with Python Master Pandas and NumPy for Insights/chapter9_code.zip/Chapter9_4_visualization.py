# Chapter 9.4: Visualizing Customer Profiles and Behaviors

import pandas as pd
import matplotlib.pyplot as plt

# Assuming 'segmentation', 'region_spend', 'age_spend' are already prepared
# For demonstration, reloading segmentation:
df = pd.read_csv('customer_transactions.csv', parse_dates=['Date'])
# ... same cleaning and segmentation steps as in Chapter9_3 ...

# Step 1: Top 10 Customers by Spend
top10 = segmentation.sort_values('TotalSpend', ascending=False).head(10)
top10['TotalSpend'].plot(kind='bar')
plt.title('Top 10 Customers by Total Spend')
plt.ylabel('Total Spend')
plt.xlabel('CustomerID')
plt.show()

# Step 2: Spend by Region
region_spend.plot(kind='bar')
plt.title('Average Spend by Region')
plt.ylabel('Average Spend')
plt.xlabel('Region')
plt.show()

# Step 3: Frequency Distribution
segmentation['Frequency'].plot(kind='hist', bins=15)
plt.title('Customer Shopping Frequency Distribution')
plt.xlabel('Number of Transactions')
plt.show()

# Step 4: Spend by Age Group
age_spend.plot(kind='bar')
plt.title('Average Spend by Age Group')
plt.ylabel('Average Spend')
plt.xlabel('Age Group')
plt.show()

# Step 5: Recency Analysis
import pandas as pd
six_months_ago = pd.Timestamp.now() - pd.DateOffset(months=6)
lapsed_customers = segmentation[segmentation['LastPurchase'] < six_months_ago]
print("Customers to re-engage:", lapsed_customers.shape[0])

# Step 6: Behavior by Gender
gender_spend = segmentation.groupby('Gender')['TotalSpend'].mean()
gender_spend.plot(kind='bar')
plt.title('Average Spend by Gender')
plt.ylabel('Average Spend')
plt.show()
