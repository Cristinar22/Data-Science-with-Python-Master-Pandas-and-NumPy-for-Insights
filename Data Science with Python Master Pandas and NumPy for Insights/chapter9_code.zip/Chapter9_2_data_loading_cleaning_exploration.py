# Chapter 9.2: Data Loading, Cleaning, and Exploration

import pandas as pd
import datetime

# Step 1: Load the Data
df = pd.read_csv('customer_transactions.csv', parse_dates=['Date'])
print(df.head())
print(df.info())

# Step 2: Cleaning the Data
print(df.isnull().sum())
df = df.dropna(subset=['CustomerID', 'Amount'])  # Drop rows with missing IDs or Amounts
df['Age'] = df['Age'].fillna(df['Age'].median())

df = df.drop_duplicates()
df['Region'] = df['Region'].str.title().str.strip()
df['Gender'] = df['Gender'].map({'M': 'Male', 'F': 'Female'})
df['Amount'] = pd.to_numeric(df['Amount'], errors='coerce')

# Step 3: Explore the Data
print("Unique customers:", df['CustomerID'].nunique())
print("Age range:", df['Age'].min(), "-", df['Age'].max())
print("Top regions:\n", df['Region'].value_counts().head())
print("Product categories:\n", df['Category'].value_counts())
