# Chapter 9.3: Segmenting Customers Using GroupBy and Aggregation

import pandas as pd

# Assuming df is already loaded and cleaned
df = pd.read_csv('customer_transactions.csv', parse_dates=['Date'])
df = df.dropna(subset=['CustomerID', 'Amount'])
df = df.drop_duplicates()
df['Region'] = df['Region'].str.title().str.strip()
df['Gender'] = df['Gender'].map({'M': 'Male', 'F': 'Female'})
df['Amount'] = pd.to_numeric(df['Amount'], errors='coerce')

# Step 1: Total Spend per Customer
customer_spend = df.groupby('CustomerID')['Amount'].sum().sort_values(ascending=False)

# Step 2: Shopping Frequency
customer_freq = df.groupby('CustomerID')['TransactionID'].nunique().sort_values(ascending=False)

# Step 3: Recency (Last Shopping Date)
customer_recent = df.groupby('CustomerID')['Date'].max()

# Step 4: Build a Segmentation Table
segmentation = pd.DataFrame({
    'TotalSpend': customer_spend,
    'Frequency': customer_freq,
    'LastPurchase': customer_recent
})
customer_info = df.drop_duplicates('CustomerID').set_index('CustomerID')
segmentation['Gender'] = customer_info['Gender']
segmentation['Age'] = customer_info['Age']
segmentation['Region'] = customer_info['Region']

# Step 5: Create Age Groups
segmentation['AgeGroup'] = pd.cut(
    segmentation['Age'],
    bins=[0, 24, 34, 44, 54, 100],
    labels=['<25', '25-34', '35-44', '45-54', '55+']
)

# Step 6: Segment by Region, Gender, and Age Group
region_spend = segmentation.groupby('Region')['TotalSpend'].mean()
age_spend = segmentation.groupby('AgeGroup')['TotalSpend'].mean()
