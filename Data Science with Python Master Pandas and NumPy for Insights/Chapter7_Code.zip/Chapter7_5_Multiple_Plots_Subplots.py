import matplotlib.pyplot as plt

scores = [88, 92, 79, 93, 85, 78, 95, 90, 80, 86]
plt.figure(figsize=(10,5))
plt.subplot(1,2,1)
plt.hist(scores)
plt.title('Histogram')
plt.subplot(1,2,2)
plt.boxplot(scores)
plt.title('Boxplot')
plt.tight_layout()
plt.show()