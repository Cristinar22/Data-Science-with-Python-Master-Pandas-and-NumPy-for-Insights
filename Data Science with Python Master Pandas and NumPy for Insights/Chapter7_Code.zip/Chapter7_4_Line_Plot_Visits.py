import matplotlib.pyplot as plt

days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
visits = [120, 150, 180, 130, 170, 200, 160]
plt.plot(days, visits, marker='o')
plt.title('Daily Website Visits')
plt.xlabel('Day')
plt.ylabel('Visits')
plt.grid(True)
plt.show()