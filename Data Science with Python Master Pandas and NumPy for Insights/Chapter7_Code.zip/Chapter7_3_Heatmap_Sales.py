import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

data = np.array([[200, 220, 210, 250],
                 [180, 170, 190, 200],
                 [230, 240, 235, 260]])
regions = ['Lagos', 'Abuja', 'Kano']
months = ['Jan', 'Feb', 'Mar', 'Apr']

sns.heatmap(data, annot=True, xticklabels=months, yticklabels=regions, cmap='YlGnBu')
plt.title('Monthly Sales by Region')
plt.xlabel('Month')
plt.ylabel('Region')
plt.show()