import matplotlib.pyplot as plt
import pandas as pd

fruits = pd.Series(['Apple', 'Banana', 'Banana', 'Orange', 'Apple', 'Apple'])
fruits.value_counts().plot(kind='bar')
plt.title('Favorite Fruits')
plt.ylabel('Count')
plt.show()