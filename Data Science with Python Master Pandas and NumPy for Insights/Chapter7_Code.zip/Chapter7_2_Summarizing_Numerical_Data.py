import pandas as pd

scores = pd.Series([88, 92, 79, 93, 85, 78, 95, 90, 80, 86])
print(scores.describe())