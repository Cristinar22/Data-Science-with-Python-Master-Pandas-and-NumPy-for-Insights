import pandas as pd

fruits = pd.Series(['Apple', 'Banana', 'Banana', 'Orange', 'Apple', 'Apple'])
print(fruits.value_counts())