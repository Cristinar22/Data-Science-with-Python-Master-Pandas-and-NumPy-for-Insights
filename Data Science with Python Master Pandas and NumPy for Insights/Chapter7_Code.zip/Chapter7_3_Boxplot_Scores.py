import matplotlib.pyplot as plt

scores = [88, 92, 79, 93, 85, 78, 95, 90, 80, 86]
plt.boxplot(scores)
plt.title('Score Spread')
plt.ylabel('Score')
plt.show()