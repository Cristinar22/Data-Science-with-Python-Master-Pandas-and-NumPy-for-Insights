import matplotlib.pyplot as plt

heights = [170, 180, 175, 160, 165, 172, 178]
weights = [65, 80, 75, 50, 55, 70, 85]
plt.scatter(heights, weights)
plt.title('Height vs Weight')
plt.xlabel('Height (cm)')
plt.ylabel('Weight (kg)')
plt.show()