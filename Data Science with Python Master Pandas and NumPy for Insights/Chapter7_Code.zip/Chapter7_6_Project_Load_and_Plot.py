import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Step 1: Load the data
df = pd.read_csv('sales.csv')
print(df.head())

# Step 2: Plot Sales Over Time
monthly = df.groupby('Month')['Sales'].sum()
monthly.plot(kind='line', marker='o')
plt.title('Monthly Total Sales')
plt.ylabel('Sales')
plt.xlabel('Month')
plt.grid(True)
plt.show()

# Step 3: Compare Regions
region = df.groupby('Region')['Sales'].sum()
region.plot(kind='bar')
plt.title('Total Sales by Region')
plt.ylabel('Sales')
plt.xlabel('Region')
plt.show()

# Step 4: Product Popularity
products = df.groupby('Product')['Sales'].sum()
products.plot(kind='pie', autopct='%1.1f%%')
plt.title('Sales Share by Product')
plt.ylabel('')
plt.show()

# Step 5: Heatmap—Region and Product
pivot = df.pivot_table(values='Sales', index='Region', columns='Product', aggfunc='sum', fill_value=0)
sns.heatmap(pivot, annot=True)
plt.title('Sales Heatmap by Region and Product')
plt.show()