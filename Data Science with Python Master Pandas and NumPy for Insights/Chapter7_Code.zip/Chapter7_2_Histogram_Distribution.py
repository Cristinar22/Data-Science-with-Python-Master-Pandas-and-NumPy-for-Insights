import matplotlib.pyplot as plt

scores = [88, 92, 79, 93, 85, 78, 95, 90, 80, 86]
plt.hist(scores, bins=5, edgecolor='black')
plt.title('Score Distribution')
plt.xlabel('Score')
plt.ylabel('Number of Students')
plt.show()