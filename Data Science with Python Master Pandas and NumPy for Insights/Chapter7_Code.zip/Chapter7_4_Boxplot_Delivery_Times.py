import matplotlib.pyplot as plt

delivery_times = [3, 4, 5, 3, 6, 5, 4, 100]
plt.boxplot(delivery_times)
plt.title('Delivery Times')
plt.ylabel('Days')
plt.show()