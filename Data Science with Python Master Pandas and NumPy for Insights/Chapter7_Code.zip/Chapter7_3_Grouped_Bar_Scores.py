import matplotlib.pyplot as plt
import pandas as pd

data = {
    'Gender': ['F', 'M', 'F', 'M', 'F', 'M'],
    'Score': [88, 85, 92, 78, 91, 83]
}
df = pd.DataFrame(data)
grouped = df.groupby('Gender')['Score'].mean()
grouped.plot(kind='bar')
plt.title('Average Score by Gender')
plt.ylabel('Average Score')
plt.show()