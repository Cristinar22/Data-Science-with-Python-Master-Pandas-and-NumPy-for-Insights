import matplotlib.pyplot as plt

products = ['Milk', 'Bread', 'Eggs']
sales = [250, 180, 150]
plt.bar(products, sales)
plt.title('Sales by Product')
plt.xlabel('Product')
plt.ylabel('Units Sold')
plt.show()