import matplotlib.pyplot as plt

ad_budget = [100, 200, 150, 300, 250]
sales = [20, 50, 35, 75, 60]
plt.scatter(ad_budget, sales)
plt.title('Ad Budget vs Sales')
plt.xlabel('Ad Budget ($)')
plt.ylabel('Sales')
plt.show()