# Chapter 1 - Hands-On Example: Loading and Exploring Your First Dataset
import pandas as pd

# Load the data
df = pd.read_csv("hw_200.csv")

# Show the first few rows
print(df.head())
