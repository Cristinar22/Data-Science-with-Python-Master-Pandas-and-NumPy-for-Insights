# Chapter 1 - Real-World Application Example: Grouping and Calculating Averages
import pandas as pd

# Load the data
df = pd.read_csv("hw_200.csv")

# Example: Grouping by a column (e.g., 'Class')
average_by_class = df.groupby("Class")["Height(Inches)"].mean()
print(average_by_class)
