# Chapter 1 - Summarize and Explore
import pandas as pd

# Assume df is already loaded
df = pd.read_csv("hw_200.csv")

# Get a summary of your data
print(df.info())

# Get some statistics (average, min, max, etc.)
print(df.describe())
