# Chapter 1 - Challenge Project: Analyzing Your Own Data
import pandas as pd

# Replace 'my_file.csv' and 'my_column' with your actual file and column names
my_data = pd.read_csv("my_file.csv")
print(my_data.head())
print(my_data.describe())
print("Average value in column:", my_data["my_column"].mean())
