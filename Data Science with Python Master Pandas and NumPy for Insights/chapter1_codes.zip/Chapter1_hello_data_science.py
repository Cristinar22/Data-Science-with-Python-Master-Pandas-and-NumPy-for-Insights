# Chapter 1 - Hello, Data Science!
print("Hello, Data Science!")
