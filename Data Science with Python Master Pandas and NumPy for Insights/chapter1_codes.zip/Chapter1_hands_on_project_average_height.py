# Chapter 1 - Hands-On Project: Calculating Average Height
import pandas as pd

# Load the data
df = pd.read_csv("hw_200.csv")

# Calculate average height
average_height = df["Height(Inches)"].mean()
print("Average height is:", average_height)
