#!/bin/bash
# Chapter 1 - Step 2: Installing Essential Packages
pip install pandas
pip install numpy
pip install matplotlib
pip install notebook
