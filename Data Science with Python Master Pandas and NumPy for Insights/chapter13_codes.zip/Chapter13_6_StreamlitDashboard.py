import streamlit as st
import pandas as pd

# Quick Start: Streamlit Dashboard
# Run this with: streamlit run Chapter13_6_StreamlitDashboard.py
df = pd.read_csv('sales.csv')
region_sales = df.groupby('Region')['Sales'].sum()

st.title('Sales Dashboard')
st.bar_chart(region_sales)
st.write("Total sales by region. Click on the chart to explore details!")