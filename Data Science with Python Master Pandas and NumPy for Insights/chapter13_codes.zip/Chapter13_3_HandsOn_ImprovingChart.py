import matplotlib.pyplot as plt
# Improved Chart Code
# Assumes df is a pandas DataFrame with a 'Sales' column
df['Sales'].plot(kind='line', marker='o')
plt.title('Monthly Sales Increased After Launch')
plt.xlabel('Month')
plt.ylabel('Sales ($)')
plt.grid(True)
plt.tight_layout()
plt.show()