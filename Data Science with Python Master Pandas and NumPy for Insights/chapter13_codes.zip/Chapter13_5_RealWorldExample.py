import matplotlib.pyplot as plt
import pandas as pd
# Real-World Example: Average Infection Rate by Department
# Assumes df is a pandas DataFrame with 'Department' and 'Infections' columns
dept_rates = df.groupby('Department')['Infections'].mean()
dept_rates.plot(kind='bar')
plt.title('Average Infection Rate by Department')
plt.xlabel('Department')
plt.ylabel('Infections per 100 Patients')
plt.tight_layout()
plt.show()