import dash
from dash import dcc, html
import pandas as pd
import plotly.express as px

# Alternative: Dash Application
# Run this with: python Chapter13_6_DashApp.py
df = pd.read_csv('sales.csv')
region_sales = df.groupby('Region')['Sales'].sum()
fig = px.bar(region_sales, x=region_sales.index, y=region_sales.values,
             labels={'x': 'Region', 'y': 'Sales'})

app = dash.Dash(__name__)
app.layout = html.Div(children=[
    html.H1(children='Sales Dashboard'),
    dcc.Graph(id='region-sales', figure=fig)
])

if __name__ == '__main__':
    app.run_server(debug=True)