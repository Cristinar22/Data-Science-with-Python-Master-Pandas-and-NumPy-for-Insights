# Project: Analyzing and Visualizing Sales or Weather Time Series Data
import pandas as pd
import matplotlib.pyplot as plt

# Step 1: Load and prepare data
df = pd.read_csv('weather.csv', parse_dates=['Date'])
df = df.set_index('Date')

# Step 2: Resample to monthly averages
monthly_temps = df['Temperature'].resample('M').mean()
print(monthly_temps)

# Step 3: Rolling 7-day rainfall sum
df['7day_rain'] = df['Rainfall'].rolling(window=7).sum()
print(df[['Rainfall', '7day_rain']].tail(10))

# Step 4: Plot temperature trends
monthly_temps.plot(marker='o')
plt.title('Monthly Average Temperature')
plt.ylabel('Temperature (°C)')
plt.grid(True)
plt.show()

# Step 5: Analyze weather types
weather_counts = df['Weather'].value_counts()
weather_counts.plot(kind='bar')
plt.title('Weather Days Count')
plt.show()

# Step 6: Encoding weather types
df['Weather_Code'] = df['Weather'].map({'Sunny': 0, 'Cloudy': 1, 'Rainy': 2})
print(df[['Weather', 'Weather_Code']].head())

# Step 7: Filter for extreme days
heavy_rain = df[df['Rainfall'] > 10]
print(heavy_rain)

# Step 8: Save your analysis
df.to_csv('weather_analysis.csv')
