# Project: Analyzing and Visualizing Sales or Weather Time Series Data
import pandas as pd
import matplotlib.pyplot as plt

# Step 1: Load and Prepare Data
df = pd.read_csv('weather.csv', parse_dates=['Date'])
df = df.set_index('Date')
print(df.head())

# Step 2: Resample to Monthly Averages
monthly_temps = df['Temperature'].resample('M').mean()
print(monthly_temps)

# Step 3: Rolling 7-Day Rainfall Sum
df['7day_rain'] = df['Rainfall'].rolling(window=7).sum()
print(df[['Rainfall', '7day_rain']].tail(10))

# Step 4: Plot Temperature Trends
monthly_temps.plot(marker='o')
plt.title('Monthly Average Temperature')
plt.ylabel('Temperature (°C)')
plt.grid(True)
plt.show()

# Step 5: Analyze Weather Types
weather_counts = df['Weather'].value_counts()
weather_counts.plot(kind='bar')
plt.title('Weather Days Count')
plt.show()

# Step 6: Encoding Weather Types
df['Weather_Code'] = df['Weather'].map({'Sunny': 0, 'Cloudy': 1, 'Rainy': 2})
print(df[['Weather', 'Weather_Code']].head())

# Step 7: Filter for Extreme Days
heavy_rain = df[df['Rainfall'] > 10]
print(heavy_rain)

# Step 8: Save Your Analysis
df.to_csv('weather_analysis.csv')