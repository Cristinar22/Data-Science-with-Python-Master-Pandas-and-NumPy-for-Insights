import pandas as pd

# Reading Dates from a File
df = pd.read_csv('sales.csv', parse_dates=['Date'])
print(df.info())

# Parsing Dates in Existing DataFrames
df['Date'] = pd.to_datetime(df['Date'], errors='coerce')

# Extracting Date Parts
df['Year'] = df['Date'].dt.year
df['Month'] = df['Date'].dt.month
df['Day'] = df['Date'].dt.day
df['Weekday'] = df['Date'].dt.day_name()

# Set Date as Index
df = df.set_index('Date')
print(df.head())