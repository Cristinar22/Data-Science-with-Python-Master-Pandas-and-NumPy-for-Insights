import pandas as pd
import matplotlib.pyplot as plt

# Converting to Category Type
df['Region'] = df['Region'].astype('category')
print(df['Region'].dtype)

# Counting and Analyzing Categories
print(df['Outcome'].value_counts())
recovery = df.groupby('Gender')['Outcome'].value_counts(normalize=True).unstack()
print(recovery)

# Encoding Categories
df['Gender_Code'] = df['Gender'].map({'Male': 0, 'Female': 1})
df = pd.get_dummies(df, columns=['Outcome'])
print(df.head())

# Visualizing Categories
df['Region'].value_counts().plot(kind='bar', color='lightblue')
plt.title('Patients by Region')
plt.show()

df['Outcome'].value_counts().plot(kind='pie', autopct='%1.1f%%')
plt.title('Patient Outcomes')
plt.ylabel('')
plt.show()
