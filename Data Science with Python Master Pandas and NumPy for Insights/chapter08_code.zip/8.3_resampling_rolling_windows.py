# Resampling, rolling windows, and time-based grouping
monthly = df.resample('M').sum()
print(monthly.head())

weekly = df.resample('W').mean()
print(weekly.head())

# Rolling window smoothing
df['7day_avg'] = df['Sales'].rolling(window=7).mean()
print(df[['Sales', '7day_avg']].tail(10))

# Time-based filtering
jan_sales = df['2023-01']
print(jan_sales)

period = df['2023-01-10':'2023-01-20']
print(period)
