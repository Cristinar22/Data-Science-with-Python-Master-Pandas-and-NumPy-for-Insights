import pandas as pd

# Reading dates from a file
df = pd.read_csv('sales.csv', parse_dates=['Date'])
print(df.info())

# Parsing dates in existing DataFrame
df['Date'] = pd.to_datetime(df['Date'], errors='coerce')

# Extracting date parts
df['Year'] = df['Date'].dt.year
df['Month'] = df['Date'].dt.month
df['Day'] = df['Date'].dt.day
df['Weekday'] = df['Date'].dt.day_name()

# Setting date as index
df = df.set_index('Date')
print(df.head())
