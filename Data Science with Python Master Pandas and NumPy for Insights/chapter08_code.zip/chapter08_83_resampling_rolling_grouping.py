# Resampling and Rolling Windows
# Assume df is already indexed by Date and has a 'Sales' column

# Resampling: Monthly totals
monthly = df.resample('M').sum()
print(monthly.head())

# Average Sales per Week
weekly = df.resample('W').mean()
print(weekly.head())

# Rolling Window: 7-day moving average
df['7day_avg'] = df['Sales'].rolling(window=7).mean()
print(df[['Sales', '7day_avg']].tail(10))

# Time-Based Filtering
jan_sales = df['2023-01']
print(jan_sales)
period = df['2023-01-10':'2023-01-20']
print(period)