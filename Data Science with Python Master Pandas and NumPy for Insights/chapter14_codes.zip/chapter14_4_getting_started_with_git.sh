# Chapter 14.4: Getting Started with Git (Team Version)

# 1. Clone an existing repository
git clone https://github.com/your-team/project.git
cd project

# OR initialize a new repository
git init

# 2. Make changes locally
# Edit your code, notebook, or data file
git add my_notebook.ipynb
git commit -m "Cleaned data and added new plots"

# 3. Push and pull changes
git pull  # Get the latest from your teammates
git push  # Upload your changes

# 4. Resolve conflicts
# If two people edit the same line, Git will ask you to choose which version to keep.
