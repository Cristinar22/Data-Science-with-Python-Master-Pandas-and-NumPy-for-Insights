import numpy as np

# Step 1: Create the Data
temps = np.array([
    32, 34, 33, 35, 36, 34, 33,
    31, 32, 30, 29, 28, 27, 30,
    33, 35, 37, 36, 34, 35, 36,
    38, 37, 36, 35, 34, 33, 32, 31
])
print("Temperatures:", temps)

# Step 2: Summarize the Data
print("Average temperature:", temps.mean())
print("Highest temperature:", temps.max())
print("Lowest temperature:", temps.min())
print("Standard deviation:", temps.std())

# Step 3: Detect Heatwaves
heatwave = temps > 36
print("Days with heatwave:", np.sum(heatwave))
print("Temperatures on heatwave days:", temps[heatwave])

# Step 4: Weekly Averages
weeks = temps.reshape((4, 7))
week_averages = weeks.mean(axis=1)
for i, avg in enumerate(week_averages, 1):
    print(f"Week {i} average: {avg:.1f}°C")

# Step 5: Fill Missing Data
temps_with_missing = temps.copy()
temps_with_missing[9] = np.nan
temps_with_missing[19] = np.nan
print("With missing data:", temps_with_missing)

print("Mean (ignoring NaN):", np.nanmean(temps_with_missing))
mean_temp = np.nanmean(temps_with_missing)
temps_filled = np.where(np.isnan(temps_with_missing), mean_temp, temps_with_missing)
print("After filling:", temps_filled)

# Step 6: Compare to a Previous Year
last_year = np.array([
    30, 32, 31, 33, 35, 32, 31,
    29, 30, 28, 27, 26, 25, 28,
    31, 33, 35, 34, 32, 33, 34,
    36, 35, 34, 33, 32, 31, 30, 29
])
change = temps - last_year
print("Temperature change per day:", change)
print("Average change:", change.mean())