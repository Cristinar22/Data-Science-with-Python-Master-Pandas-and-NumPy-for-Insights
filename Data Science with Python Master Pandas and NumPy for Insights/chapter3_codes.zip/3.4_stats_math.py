import numpy as np

# Quick Stats
scores = np.array([56, 78, 92, 88, 45])
print("Median:", np.median(scores))
print("Variance:", np.var(scores))
print("Std. deviation:", np.std(scores))
print("90th percentile:", np.percentile(scores, 90))

# Math Functions
angles = np.array([0, np.pi/2, np.pi])
print("Sine values:", np.sin(angles))
print("Cosine values:", np.cos(angles))

numbers = np.array([4, 9, 16, 25])
print("Square roots:", np.sqrt(numbers))
print("Natural logs:", np.log(numbers))