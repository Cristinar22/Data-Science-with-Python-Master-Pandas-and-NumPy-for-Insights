import numpy as np

# Arithmetic
a = np.array([1, 2, 3])
b = np.array([10, 20, 30])
print(a + b)   # [11 22 33]
print(a * b)   # [10 40 90]
print(a - b)   # [-9 -18 -27]
print(a / b)   # [0.1 0.1 0.1]

# With scalars
print(a + 5)   # [6 7 8]

# Broadcasting
table = np.array([[1, 2], [3, 4]])
col = np.array([10, 20])
print(table + col)

# Aggregation
arr = np.array([10, 20, 30, 40])
print(arr.sum())   
print(arr.mean())  
print(arr.max())   
print(arr.min())   
print(arr.std())   

# 2D arrays aggregation
table = np.array([[1, 2, 3], [4, 5, 6]])
print(table.sum(axis=0)) # [5 7 9]
print(table.sum(axis=1)) # [6 15]