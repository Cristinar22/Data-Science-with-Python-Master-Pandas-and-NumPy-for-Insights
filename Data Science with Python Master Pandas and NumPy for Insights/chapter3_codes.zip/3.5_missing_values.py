import numpy as np

# Missing values
data = np.array([10, np.nan, 15, 20, np.nan])
print("Original:", data)
print("Mean (with NaN):", data.mean())

# Ignore missing values
print("Mean (ignoring NaN):", np.nanmean(data))
print("Count missing:", np.isnan(data).sum())

# Replace missing values
data = np.where(np.isnan(data), 0, data)
print("No more NaN:", data)