import numpy as np

# Importing NumPy
import numpy as np

# Creating Arrays from lists
data = [2, 4, 6, 8]
arr = np.array(data)
print(arr)  # [2 4 6 8]

# From scratch
zeros = np.zeros(5)          # [0. 0. 0. 0. 0.]
ones = np.ones(4)            # [1. 1. 1. 1.]
arange = np.arange(0, 10, 2) # [0 2 4 6 8]
linspace = np.linspace(0, 1, 6)  # [0. 0.2 0.4 0.6 0.8 1.]

# Random numbers
rand_arr = np.random.rand(3) # 3 random floats, 0 to 1

# 2D Arrays (Tables)
table = np.array([[1, 2, 3], [4, 5, 6]])
print(table)
print(table.shape)  # (2, 3)

# Reshaping
arr = np.arange(12)   
arr2d = arr.reshape((3, 4)) 
print(arr2d)

# Flattening (to 1D)
flat = arr2d.flatten()
print(flat)

# Indexing and Slicing
one_d = np.array([10, 20, 30, 40])
print(one_d[2])   # 30
print(one_d[-1])  # 40
print(one_d[1:3]) # [20 30]

matrix = np.array([[1, 2, 3], [4, 5, 6]])
print(matrix[0, 1])  # 2
print(matrix[:, 2])  # [3 6]

# Assignment
one_d[2] = 99
matrix[1, 0] = 77
print(one_d)      
print(matrix)   