# Chapter 11.1: Debugging Common Pandas and NumPy Errors

# 1. Typos and Misspelled Columns
# Use df.columns to list all columns and check spelling.
df['Ammount']  # Mistyped column name -> KeyError

# 2. Indexing Errors
# For rows by position, use .iloc; for columns by name, use df['column_name']
df.iloc[10]  
df['column_name']

# 3. Data Type Confusion
# Convert with pd.to_numeric
df['Amount'] = pd.to_numeric(df['Amount'], errors='coerce')

# 4. Chained Assignment Warnings
# Use .loc for safe assignment
df.loc[df['Amount'] > 100, 'Status'] = 'High'

# 5. Working with Missing Values
# Fill missing values
df['Score'] = df['Score'].fillna(df['Score'].mean())

# Hands-On Debugging Practice
import pandas as pd

df = pd.DataFrame({'Amount': ['100', '200', 'abc', '', '300']})
df['Amount'] = pd.to_numeric(df['Amount'], errors='coerce')
print(df)
df['Amount'] = df['Amount'].fillna(0)
print(df)
