# Chapter 11.2: Optimizing Code for Large Datasets (Memory, Speed)

import pandas as pd

# 1. Load Only What You Need
df = pd.read_csv('big_data.csv', usecols=['Date', 'Amount', 'Category'])

# 2. Use Efficient Data Types
df['Region'] = df['Region'].astype('category')
df['Age'] = df['Age'].astype('int32')

# 3. Chunking—Read Large Files in Pieces
chunks = pd.read_csv('big_data.csv', chunksize=100000)
for chunk in chunks:
    print(chunk['Amount'].sum())

# 4. Avoid Loops—Use Vectorized Operations
total = df['Amount'].sum()

# 5. Use .apply() Carefully
# Instead of slow .apply():
df['HighValue'] = df['Amount'] > 1000

# Memory Usage Check
print(df.info(memory_usage='deep'))
print(df.memory_usage(deep=True))
