# Chapter 11.3: Data Validation, Quality Checks, and Sanity Tests

# 1. Value Ranges
print(df['Age'].describe())
print(df[df['Amount'] < 0])

# 2. Unique Values
print(df['Region'].unique())
print(df['Category'].value_counts())

# 3. Duplicates
dupes = df.duplicated().sum()
print("Duplicate rows:", dupes)

# 4. Consistency Checks
print(df.groupby('CustomerID')['Gender'].nunique().max())

# Sanity Tests Example
# Negative sales, ages over 120, future dates
sanity_issues = df[(df['Amount'] < 0) | (df['Age'] > 120)]
print(sanity_issues)
