#!/bin/bash
# Chapter 11.5: Version Control Basics (Git Intro)

# 1. Install Git (visit git-scm.com)
# 2. Set up a repository
cd your_project_folder
git init

# 3. Add files and commit
git add my_analysis.py
git commit -m "First version of my analysis"

# 4. Make changes and track them
# Edit file, then:
git add my_analysis.py
git commit -m "Cleaned up code, added new plot"

# 5. Push to GitHub
# Follow instructions on GitHub to push your repo
