# Chapter 11.4: Documentation, Commenting, and Reproducibility

# Example of clear comment
# Filter out transactions below $10
df = df[df['Amount'] >= 10]

# Descriptive variable names
total_sales = df['Amount'].sum()
avg_age = df['Age'].mean()

# Markdown example in notebooks:
# # Calculate average sales per region

# Save code snapshot
# Note which version of data you used (e.g., data_v1.csv)

# Jupyter Notebook usage:
# Use cells to mix code, comments, and charts for reproducibility
