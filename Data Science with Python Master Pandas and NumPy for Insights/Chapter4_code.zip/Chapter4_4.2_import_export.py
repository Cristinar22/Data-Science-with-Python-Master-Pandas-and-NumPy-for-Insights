import pandas as pd

# Importing Data
df_csv = pd.read_csv("students.csv")
df_excel = pd.read_excel("students.xlsx")
df_json = pd.read_json("students.json")

# Exporting Data
df_csv.to_csv("results.csv", index=False)
df_csv.to_excel("results.xlsx", index=False)
df_csv.to_json("results.json")
