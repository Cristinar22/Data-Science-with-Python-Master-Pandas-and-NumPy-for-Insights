import pandas as pd

# Selecting Columns
print(df['score'])
print(df[['name', 'score']])

# Selecting Rows by Position
print(df.iloc[0])      # First row by position
print(df.iloc[0:2])    # First two rows by position

# Selecting Rows by Label
print(df.loc[0])       # First row by label

# Slicing Rows
print(df[1:4])         # Rows 1 to 3

# Setting and Resetting Index
df_indexed = df.set_index('name')
print(df_indexed)
df_reset = df_indexed.reset_index()
print(df_reset)
