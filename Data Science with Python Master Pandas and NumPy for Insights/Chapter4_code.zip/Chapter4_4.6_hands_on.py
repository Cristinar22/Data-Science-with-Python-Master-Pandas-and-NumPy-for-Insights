import pandas as pd

# Scenario 1: Movie Dataset Exploration
df_movies = pd.read_csv("movies.csv")
print(df_movies.info())
print(df_movies.describe())
print(df_movies.head(10))

print(df_movies['genre'].value_counts())
print(df_movies[df_movies['rating'] == df_movies['rating'].max()])
print(df_movies.groupby('genre')['rating'].mean())

great_recent = df_movies[(df_movies['year'] > 2015) & (df_movies['rating'] > 8)]
great_recent.to_csv("great_recent_movies.csv", index=False)

# Scenario 2: Product Dataset Exploration
df_products = pd.read_csv("products.csv")
print(df_products[df_products['Quantity'] > 50])

print(df_products.groupby('Category')['Price'].mean())

avg_price = df_products['Price'].mean()
cheap_products = df_products[df_products['Price'] < avg_price]
cheap_products.to_csv("cheap_products.csv", index=False)
print(cheap_products)
