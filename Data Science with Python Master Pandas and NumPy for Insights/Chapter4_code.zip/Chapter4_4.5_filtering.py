import pandas as pd

# Filtering Rows
expensive = df[df['Price'] > 2]
print(expensive)

mid_quantity = df[(df['Quantity'] >= 20) & (df['Quantity'] <= 100)]
print(mid_quantity)

# Filtering Movies Example
high_rated = df[df['rating'] > 8]
print(high_rated)

recent_good = df[(df['year'] > 2010) & (df['rating'] > 7)]
print(recent_good)
