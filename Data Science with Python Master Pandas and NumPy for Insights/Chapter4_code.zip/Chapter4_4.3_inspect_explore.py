import pandas as pd

# Assume df is already loaded
# Inspecting and Exploring Data
print(df.head())        # First 5 rows
print(df.tail())        # Last 5 rows
print(df.info())        # Info summary
print(df.describe())    # Descriptive stats
print(df.columns)       # Column names
print(df.shape)         # Shape of the DataFrame
