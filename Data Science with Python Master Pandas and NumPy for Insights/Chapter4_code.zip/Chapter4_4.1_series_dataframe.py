import pandas as pd

# Creating a Series
numbers = [10, 20, 30, 40]
series = pd.Series(numbers)
print(series)

# Creating a DataFrame
data = {
    'name': ['Aisha', 'Ngozi', 'Tom'],
    'score': [88, 76, 92],
    'age': [22, 21, 23]
}
df = pd.DataFrame(data)
print(df)
