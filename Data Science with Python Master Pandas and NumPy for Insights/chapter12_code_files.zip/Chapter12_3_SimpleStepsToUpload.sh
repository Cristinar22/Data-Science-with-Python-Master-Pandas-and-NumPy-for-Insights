git init
git add .
git commit -m "Initial portfolio upload"
git branch -M main
git remote add origin https://github.com/yourname/data-science-portfolio.git
git push -u origin main
