#!/bin/bash
# Chapter 12.3 GitHub: Simple steps to upload your portfolio

# Initialize a new repository
git init

# Add all files
git add .

# Commit changes
git commit -m "Initial portfolio upload"

# Rename main branch
git branch -M main

# Add remote origin (replace with your repo URL)
git remote add origin https://github.com/yourname/data-science-portfolio.git

# Push to GitHub
git push -u origin main
